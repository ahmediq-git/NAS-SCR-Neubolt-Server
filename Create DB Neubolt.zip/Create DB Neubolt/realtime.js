const mysql = require('mysql2');
const fs = require('fs');
const csv = require('csv-parser');

//sql conenction details
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'root1234',
  database: 'NeuboltDB',
});

// Connect to the database
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;
  }
  console.log('Connected to MySQL database!');

  // After connecting, drop all tables in the database
  DropTables();

  // Create a new table for Rickshaw 1
  createRickshawTable('1');


  //create a new table for Rickshaw 2
  createRickshawTable('2');

  //create a new table for Station 1
  createStationTable('1');


  //simulate realtime database by adding a row every second to each table
  insertRowsPeriodically();

});


// All the functions

// To drop all the tables before starting the program
const DropTables = () => {
    const tableNames = [`RickshawTable1`, `RickshawTable2`, `StationTable1`];
  
    // Loop through the tableNames array and execute the DROP TABLE query for each table
    tableNames.forEach((tableName) => {
      const deleteTableQuery = `DROP TABLE IF EXISTS ${tableName}`;
  
      connection.query(deleteTableQuery, (err, results) => {
        if (err) {
          console.error(`Error deleting ${tableName}:`, err);
          return;
        }
        console.log(`${tableName} deleted successfully!`);
      });
    });
  };
  
// Makes a table for the Rickshaw
const createRickshawTable = (inputParameter) => {
    const tableName = `RickshawTable${inputParameter}`;
  
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS ${tableName} (
        Time TIMESTAMP,
        EV_ID CHAR(9),
        EV_Voltage FLOAT,
        EV_Current FLOAT,
        EV_MCU_Rpm INT,
        EV_MCU_Dis FLOAT,
        EV_MCU_Temp FLOAT,
        S1_B_Slot INT,
        S1_B_ID CHAR(21),
        S1_B_Temp FLOAT,
        S1_B_SoC INT,
        S1_B_SoH INT,
        S1_B_Vol FLOAT,
        S1_B_Curr FLOAT,
        S2_B_Slot INT,
        S2_B_ID CHAR(21),
        S2_B_Temp FLOAT,
        S2_B_SoC INT,
        S2_B_SoH INT,
        S2_B_Vol FLOAT,
        S2_B_Curr FLOAT,
        S3_B_Slot INT,
        S3_B_ID CHAR(21),
        S3_B_Temp FLOAT,
        S3_B_SoC INT,
        S3_B_SoH INT,
        S3_B_Vol FLOAT,
        S3_B_Curr FLOAT,
        S4_B_Slot INT,
        S4_B_ID CHAR(21),
        S4_B_Temp FLOAT,
        S4_B_SoC INT,
        S4_B_SoH INT,
        S4_B_Vol FLOAT,
        S4_B_Curr FLOAT
      )`;
  
    connection.query(createTableQuery, (err, results) => {
      if (err) {
        console.error(`Error creating ${tableName}:`, err);
        return;
      }
      console.log(`${tableName} created successfully!`);
    //   connection.end();
    });
  };




  const insertDataIntoRickshawTable = (inputParameter, data) => {
    const tableName = `RickshawTable${inputParameter}`;
      
    const insertDataQuery = `
      INSERT INTO ${tableName} (
        Time, EV_ID, EV_Voltage, EV_Current, EV_MCU_Rpm, EV_MCU_Dis, EV_MCU_Temp,
        S1_B_Slot, S1_B_ID, S1_B_Temp, S1_B_SoC, S1_B_SoH, S1_B_Vol, S1_B_Curr,
        S2_B_Slot, S2_B_ID, S2_B_Temp, S2_B_SoC, S2_B_SoH, S2_B_Vol, S2_B_Curr,
        S3_B_Slot, S3_B_ID, S3_B_Temp, S3_B_SoC, S3_B_SoH, S3_B_Vol, S3_B_Curr,
        S4_B_Slot, S4_B_ID, S4_B_Temp, S4_B_SoC, S4_B_SoH, S4_B_Vol, S4_B_Curr
      )
      VALUES ?`;
  
    connection.query(insertDataQuery, [data], (err, results) => {
      if (err) {
        console.error(`Error inserting data into ${tableName}:`, err);
        return;
      }
      console.log(`Data inserted successfully into ${tableName}!`);
    });
  };




  //Makes a table for the station
  const createStationTable = (inputParameter) => {
    const tableName = `StationTable${inputParameter}`;
  
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS ${tableName} (
        Time TIMESTAMP,
        BSS_ID VARCHAR(21),
        BSS1_B_Slot INT,
        BSS1_Voltage FLOAT,
        BSS1_Current FLOAT,
        BSS1_Power FLOAT,
        BSS2_B_Slot INT,
        BSS2_Voltage FLOAT,
        BSS2_Current FLOAT,
        BSS2_Power FLOAT,
        BSS3_B_Slot INT,
        BSS3_Voltage FLOAT,
        BSS3_Current FLOAT,
        BSS3_Power FLOAT,
        BSS4_B_Slot INT,
        BSS4_Voltage FLOAT,
        BSS4_Current FLOAT,
        BSS4_Power FLOAT,
        S1_B_Slot INT,
        S1_B_ID VARCHAR(21),
        S1_B_Temp FLOAT,
        S1_B_SoC FLOAT,
        S1_B_SoH FLOAT,
        S1_B_Vol FLOAT,
        S1_B_Curr FLOAT,
        S2_B_Slot INT,
        S2_B_ID VARCHAR(21),
        S2_B_Temp FLOAT,
        S2_B_SoC FLOAT,
        S2_B_SoH FLOAT,
        S2_B_Vol FLOAT,
        S2_B_Curr FLOAT,
        S3_B_Slot INT,
        S3_B_ID VARCHAR(21),
        S3_B_Temp FLOAT,
        S3_B_SoC FLOAT,
        S3_B_SoH FLOAT,
        S3_B_Vol FLOAT,
        S3_B_Curr FLOAT,
        S4_B_Slot INT,
        S4_B_ID VARCHAR(21),
        S4_B_Temp FLOAT,
        S4_B_SoC FLOAT,
        S4_B_SoH FLOAT,
        S4_B_Vol FLOAT,
        S4_B_Curr FLOAT,
        S5_B_Slot INT,
        S5_B_ID VARCHAR(21),
        S5_B_Temp FLOAT,
        S5_B_SoC FLOAT,
        S5_B_SoH FLOAT,
        S5_B_Vol FLOAT,
        S5_B_Curr FLOAT,
        S6_B_Slot INT,
        S6_B_ID VARCHAR(21),
        S6_B_Temp FLOAT,
        S6_B_SoC FLOAT,
        S6_B_SoH FLOAT,
        S6_B_Vol FLOAT,
        S6_B_Curr FLOAT,
        S7_B_Slot INT,
        S7_B_ID VARCHAR(21),
        S7_B_Temp FLOAT,
        S7_B_SoC FLOAT,
        S7_B_SoH FLOAT,
        S7_B_Vol FLOAT,
        S7_B_Curr FLOAT,
        S8_B_Slot INT,
        S8_B_ID VARCHAR(21),
        S8_B_Temp FLOAT,
        S8_B_SoC FLOAT,
        S8_B_SoH FLOAT,
        S8_B_Vol FLOAT,
        S8_B_Curr FLOAT,
        S9_B_Slot INT,
        S9_B_ID VARCHAR(21),
        S9_B_Temp FLOAT,
        S9_B_SoC FLOAT,
        S9_B_SoH FLOAT,
        S9_B_Vol FLOAT,
        S9_B_Curr FLOAT,
        S10_B_Slot INT,
        S10_B_ID VARCHAR(21),
        S10_B_Temp FLOAT,
        S10_B_SoC FLOAT,
        S10_B_SoH FLOAT,
        S10_B_Vol FLOAT,
        S10_B_Curr FLOAT,
        S11_B_Slot INT,
        S11_B_ID VARCHAR(21),
        S11_B_Temp FLOAT,
        S11_B_SoC FLOAT,
        S11_B_SoH FLOAT,
        S11_B_Vol FLOAT,
        S11_B_Curr FLOAT,
        S12_B_Slot INT,
        S12_B_ID VARCHAR(21),
        S12_B_Temp FLOAT,
        S12_B_SoC FLOAT,
        S12_B_SoH FLOAT,
        S12_B_Vol FLOAT,
        S12_B_Curr FLOAT,
        S13_B_Slot INT,
        S13_B_ID VARCHAR(21),
        S13_B_Temp FLOAT,
        S13_B_SoC FLOAT,
        S13_B_SoH FLOAT,
        S13_B_Vol FLOAT,
        S13_B_Curr FLOAT,
        S14_B_Slot INT,
        S14_B_ID VARCHAR(21),
        S14_B_Temp FLOAT,
        S14_B_SoC FLOAT,
        S14_B_SoH FLOAT,
        S14_B_Vol FLOAT,
        S14_B_Curr FLOAT,
        S15_B_Slot INT,
        S15_B_ID VARCHAR(21),
        S15_B_Temp FLOAT,
        S15_B_SoC FLOAT,
        S15_B_SoH FLOAT,
        S15_B_Vol FLOAT,
        S15_B_Curr FLOAT,
        S16_B_Slot INT,
        S16_B_ID VARCHAR(21),
        S16_B_Temp FLOAT,
        S16_B_SoC FLOAT,
        S16_B_SoH FLOAT,
        S16_B_Vol FLOAT,
        S16_B_Curr FLOAT
      )`;
  
    connection.query(createTableQuery, (err, results) => {
      if (err) {
        console.error(`Error creating ${tableName}:`, err);
        return;
      }
      console.log(`${tableName} created successfully!`);
    //   connection.end();
    });
  };

  // Function to insert data into the StationTable
const insertDataIntoStationTable = (inputParameter, data) => {
    const tableName = `StationTable${inputParameter}`;
  
    const insertDataQuery = `
      INSERT INTO ${tableName} (
        Time,
        BSS_ID,
        BSS1_B_Slot, BSS1_Voltage, BSS1_Current, BSS1_Power,
        BSS2_B_Slot, BSS2_Voltage, BSS2_Current, BSS2_Power,
        BSS3_B_Slot, BSS3_Voltage, BSS3_Current, BSS3_Power,
        BSS4_B_Slot, BSS4_Voltage, BSS4_Current, BSS4_Power,
        S1_B_Slot, S1_B_ID, S1_B_Temp, S1_B_SoC, S1_B_SoH, S1_B_Vol, S1_B_Curr,
        S2_B_Slot, S2_B_ID, S2_B_Temp, S2_B_SoC, S2_B_SoH, S2_B_Vol, S2_B_Curr,
        S3_B_Slot, S3_B_ID, S3_B_Temp, S3_B_SoC, S3_B_SoH, S3_B_Vol, S3_B_Curr,
        S4_B_Slot, S4_B_ID, S4_B_Temp, S4_B_SoC, S4_B_SoH, S4_B_Vol, S4_B_Curr,
        S5_B_Slot, S5_B_ID, S5_B_Temp, S5_B_SoC, S5_B_SoH, S5_B_Vol, S5_B_Curr,
        S6_B_Slot, S6_B_ID, S6_B_Temp, S6_B_SoC, S6_B_SoH, S6_B_Vol, S6_B_Curr,
        S7_B_Slot, S7_B_ID, S7_B_Temp, S7_B_SoC, S7_B_SoH, S7_B_Vol, S7_B_Curr,
        S8_B_Slot, S8_B_ID, S8_B_Temp, S8_B_SoC, S8_B_SoH, S8_B_Vol, S8_B_Curr,
        S9_B_Slot, S9_B_ID, S9_B_Temp, S9_B_SoC, S9_B_SoH, S9_B_Vol, S9_B_Curr,
        S10_B_Slot, S10_B_ID, S10_B_Temp, S10_B_SoC, S10_B_SoH, S10_B_Vol, S10_B_Curr,
        S11_B_Slot, S11_B_ID, S11_B_Temp, S11_B_SoC, S11_B_SoH, S11_B_Vol, S11_B_Curr,
        S12_B_Slot, S12_B_ID, S12_B_Temp, S12_B_SoC, S12_B_SoH, S12_B_Vol, S12_B_Curr,
        S13_B_Slot, S13_B_ID, S13_B_Temp, S13_B_SoC, S13_B_SoH, S13_B_Vol, S13_B_Curr,
        S14_B_Slot, S14_B_ID, S14_B_Temp, S14_B_SoC, S14_B_SoH, S14_B_Vol, S14_B_Curr,
        S15_B_Slot, S15_B_ID, S15_B_Temp, S15_B_SoC, S15_B_SoH, S15_B_Vol, S15_B_Curr,
        S16_B_Slot, S16_B_ID, S16_B_Temp, S16_B_SoC, S16_B_SoH, S16_B_Vol, S16_B_Curr
      )
      VALUES ?`;
  
    connection.query(insertDataQuery, [data], (err, results) => {
      if (err) {
        console.error(`Error inserting data into ${tableName}:`, err);
        return;
      }
      console.log(`Data inserted successfully into ${tableName}!`);
    //   connection.end();
    });
  };


// Simulating the realtime database



function processCSV(csvFilePath, tableName) {
    return new Promise((resolve, reject) => {
      const dataArray = [];
  
      fs.createReadStream(csvFilePath)
        .pipe(csv())
        .on('data', (row) => {
          dataArray.push(Object.values(row));
        })
        .on('end', () => {
          console.log(`CSV file ${csvFilePath} processed.`);
          resolve({ tableName, dataArray });
        })
        .on('error', (err) => {
          reject(err);
        });
    });
  }
  
  async function insertRowsPeriodically() {
    const csvFiles = [
      'RickshawDriver1_All.csv',
      'RickshawDriver2_All.csv',
      'BSS_Station_All.csv',
    ];
  
    const tableNames = ['RickshawTable1', 'RickshawTable2', 'StationTable1'];
  
    for (let i = 0; i < csvFiles.length; i++) {
      try {
        const { tableName, dataArray } = await processCSV(csvFiles[i], tableNames[i]);
        const interval = setInterval(() => {
          if (dataArray.length > 0) {
            const data = dataArray.shift();
            if (tableName.startsWith('RickshawTable')) {
              insertDataIntoRickshawTable(tableName.charAt(tableName.length - 1), [data]);
            } else {
              insertDataIntoStationTable(tableName.charAt(tableName.length - 1), [data]);
            }
          } else {
            clearInterval(interval);
          }
        }, 1000);
      } catch (err) {
        console.error(`Error processing CSV file ${csvFiles[i]}:`, err);
      }
    }
  }