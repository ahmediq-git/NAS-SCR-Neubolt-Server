import os
import csv

input_directory = "BSS"
output_file = "BSS_Station_All.csv"

# Get a list of all the text files in the input directory
input_files = [file for file in os.listdir(input_directory) if file.endswith(".txt")]

with open(output_file, "w", newline="") as csv_file:
    writer = csv.writer(csv_file)

    # Iterate over each input file
    for input_file in input_files:
        input_path = os.path.join(input_directory, input_file)
        print("Converting", input_path, "to CSV")
        with open(input_path, "r") as txt_file:
            lines = txt_file.readlines()

            # Extract the header from the first line
            header = lines[0].strip().split(",")

            # Write the header to the CSV file (only for the first file)
            if input_files.index(input_file) == 0:
                writer.writerow(header)

            # Write the data rows to the CSV file
            for line in lines[1:]:
                # Remove the angle brackets at the beginning and end of each line
                line = line.strip()[1:-1]

                values = line.split(",")

                writer.writerow(values)

print("Conversion completed successfully!")
