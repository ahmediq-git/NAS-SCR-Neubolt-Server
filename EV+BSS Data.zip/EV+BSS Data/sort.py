import csv

def sort_csv_by_time(input_file, output_file):
    # Step 1: Read the CSV file and extract the field names
    with open(input_file, 'r', newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        fieldnames = reader.fieldnames

        # Step 2: Sort the list of dictionaries based on the time column
        sorted_data = sorted(reader, key=lambda x: x['Time'])

    # Step 3: Write the sorted data back to a new CSV file
    with open(output_file, 'w', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(sorted_data)
    print('completed making', output_file)

# Usage example
input_file = 'RickshawDriver1_All_unsorted.csv'  # Replace with the path to yosur input CSV file
output_file = 'sorted_r1.csv'  # Replace with the desired output file name
sort_csv_by_time('RickshawDriver1_All_unsorted.csv', 'RickshawDriver1_All.csv')
sort_csv_by_time('RickshawDriver2_All_unsorted.csv', 'RickshawDriver2_All.csv')
sort_csv_by_time('BSS_Station_All_unsorted.csv', 'BSS_Station_All.csv')